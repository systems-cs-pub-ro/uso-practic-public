#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int sum(int a, int b) {
	return a + b;
}

int main() {
	int a, b;

	srand(time(NULL));

	a = rand() % 100;
	b = rand() % 100;

	printf("Suma numerelor %d si %d este: %d\n", a, b, sum(a, b));

	return 0;
}
