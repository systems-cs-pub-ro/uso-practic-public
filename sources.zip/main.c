#include <stdio.h>
#include "max.h"

int main(void)
{
	int a = 10, b = 20;
	if (max(a, b))
		printf("a > b\n");
	else
		printf("a < b\n");
	return 0;
}
