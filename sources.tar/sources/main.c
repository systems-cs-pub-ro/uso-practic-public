#include<stdio.h>

int main(void) {
	fprintf(stdout, "Psst! I have something to tell you\n");
	fprintf(stderr, "[ERROR] Oopsie\n");
	fprintf(stderr, "[ERROR] My spider-sense is tingling\n");
	return 0;
}
